<!DOCTYPE html>
<html>
<head>
<title>Tambah data</title>
</head>
<body>
<h1>Tambah Data Barang</h1>
<br/>
<a href="index.php">Data Barang</a>
<br/><br/>
<form action="prosestambah.php" method="post" enctype="multipart/form-
data">

<table width="300" >
<tr>
<td>kode barang</td>
<td><input type="text" name="kode barang"></td>
</tr>
<tr>
<td>nama barang</td>
<td><input type="text" name="nama barang" requied></td>
</tr>
<tr>
<td>satuan</td>
<td><td><input type="number" name="satuan" requied></td></td>
</tr>
<tr>
<td>kategori</td>
<td>
<input type="radio" value=alatpembersih name="kategori">alat pembersih
<input type="radio" value=peralatandapur name="kategori">peralatan dapur
<input type="radio" value=peralatankamartidur name="kategori">peralatan kamar tidur
</td></tr>
<tr>
<td>harga modal</td>
<td><input type="text" name="harga modal" requied></td>
</tr>
<tr>
<td>harga jual</td>
<td><input type="text" name="harga jual" requied></td>
</tr>
<tr>
<td>photo</td>
<td><input type="file" name="photo" requied></td>
</tr>

</select>

<br/><br/>
<input name="save" type="submit" value="SIMPAN">
<input name="BtnBatal" type="reset" value="BATAL" />
</td>
</tr>
</table>
</form>
</body>
</html>