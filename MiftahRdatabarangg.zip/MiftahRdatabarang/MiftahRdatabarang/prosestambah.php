<!DOCTYPE html>
<html>
<head>
<title>Upload File </title>
</head>
<body>
<h1>Upload File </h1>
<?php

include 'koneksi.php';
if($_POST['save']){
// menangkap data yang di kirim dari form
$kode = $_POST['kode_barang'];
$nama = $_POST['nama_barang'];
$satuan = $_POST['satuan'];
$kategori = $_POST['kategori'];
$hrgmodal = $_POST['harga_modal'];
$hrgjual = $_POST['harga_jual'];
$ekstensi_diperbolehkan = array('png', 'jpg');

move_uploaded_file($kode, 'file/'.$kode);

$photo = $_FILES['ssssss']['name'];
$x = explode('.', $photo);
$ekstensi = strtolower(end($x));
$ukuran = $_FILES['file/']['size'];
$file_tmp = $_FILES['file/']['tmp_name'];
$namafile = 'file/'.$kode.'.jpg';
if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
if ($ukuran < 1044070) {
move_uploaded_file($file_tmp, 'file/'.$namafile);
$query = mysqli_query($koneksi, "INSERT INTO tbbarang(kodebarang, namabarang, satuan, kategori, hargamodal, hargajual, photo) VALUES ('$kode', '$nama', '$satuan', '$kategori', '$hrgmodal', '$hrgjual', '$namafile')");


$query = $koneksi->prepare(" insert into tbbarang(kodebarang, namabarang, satuan, kategori, hargamodal, hargajual, photo) VALUES (?, ?, ?, ?, ?, ?, ?)");
$query->bind_param("sssssss", $kode, $nama, $satuan, $kategori, $hrgmodal, $hrgjual, $namafile);
$query->execute();
$query->close();

if($query){
echo "<script>alert('DATA BERHASIL DI

SIMPAN');window.location='index.php';</script>";

}else{
echo "<script>alert('GAGAL MENGUPLOAD

GAMBAR');window.location='index.php';</script>";

}
}else{
echo "<script>alert('UKURAN FILE TERLALU

BESAR');window.location='tambahdata.php';</script>";

}
}else{
echo "<script>alert('EKSTENSI FILE YANG DI UPLOAD TIDAK DI

PERBOLEHKAN');window.location='tambahdata.php';</script>";
}
}

?>
</body>
</html>