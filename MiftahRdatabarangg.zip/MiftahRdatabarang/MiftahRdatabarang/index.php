<!DOCTYPE html>
<html>
<head>
<title>Tambah Data </title>
</head>
<body>
<h1>Tambah Data Barang</h1>
<?php
include 'koneksi.php';
?>
<br/>
<a href="tambahdata.php">Tambah Data</a>
<br/><br/>
<table border="1" cellpadding="10">
<tr>
<th>no</th>    
<th>kode barang</th>
<th>nama barang</th>
<th>satuan</th>
<th>kategori</th>
<th>harga modal</th>
<th>harga jual</th>
<th>photo</th>
<th>action</th>
</tr>
<?php
$no = 1;
$data = mysqli_query($koneksi,"select * from tbbarang");
while($d = mysqli_fetch_array($data)){
?>
<tr>
<td><?php echo $no++; ?></td>
<td><?php echo $d['kode barang']; ?></td>
<td><?php echo $d['nama barang']; ?></td>
<td><?php echo $d['satuan']; ?></td>
<td><?php echo $d['kategori']; ?></td>
<td><?php echo $d['harga modal']; ?></td>
<td><?php echo $d['harga jual']; ?></td>
<td>
<img src="<?php echo "file/".$d['photo']; ?>" width="100"
height="130" >
</td>
<td>
<a href="edit_databarang.php?id=<?php echo $d['kode barang']; 
?>">Edit</a> |
<a href="hapus.php?id=<?php echo $d['kode barang']; ?>"
onclick="return confirm('Anda yakin akan menghapus data ini? \n<?php echo 
$d['kode barang']; ?>')">Hapus</a>
</td>
</tr>
<?php } ?>
</table>
<br/>
<?php
echo "Total data : ". mysqli_num_rows($data)." dbbarang";
?>
</body>
</html>